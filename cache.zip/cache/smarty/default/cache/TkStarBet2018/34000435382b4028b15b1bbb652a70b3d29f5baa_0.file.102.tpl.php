<?php
/* Smarty version 3.1.31, created on 2018-10-15 15:29:13
  from "C:\xampp\htdocs\themes\default\TkStarBet2018\modules\users\help\102.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.31',
  'unifunc' => 'content_5bc48111b3d253_63582051',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '34000435382b4028b15b1bbb652a70b3d29f5baa' => 
    array (
      0 => 'C:\\xampp\\htdocs\\themes\\default\\TkStarBet2018\\modules\\users\\help\\102.tpl',
      1 => 1531334364,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:modules/users/help/menus.tpl' => 1,
  ),
),false)) {
function content_5bc48111b3d253_63582051 (Smarty_Internal_Template $_smarty_tpl) {
if (!is_callable('smarty_function_assets_url')) require_once 'C:\\xampp\\htdocs\\TkStarApplication\\smarty\\plugins\\function.assets_url.php';
?>
<div class="container">
	<div class="page-content light">
		<div class="ph15"></div>
		<div class="inline container">
			<?php $_smarty_tpl->_subTemplateRender("file:modules/users/help/menus.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

			<div class="left static-content">
				<div class="page-area container inline form-container">
					<div class="page-title">آموزش ثبت فرم میکس</div>
					<div class="p15 text-content-page" style="font-size: 17px !important; text-align: justify !important;">
						<p style="color: #ffd33b !important;">* آموزش ثبت فرم میکس *</p>
						<p>برای ثبت فرم میکس می توانید ضرایب مورد نظر را انتخاب نمایید. سپس در بخش شرط های انتخاب شده دو بخش وجود دارد :</p>
						<p><text style="color: #ffd33b !important;">تکی ها :</text> که برای ثبت فرم تکی کاربرد دارد و عدد داخل پرانتز به معنی این است که می توان 4 فرم تکی را با مبلغ یکسان همزمان ثبت کرد. بدین منظور در کنار تکی ها مبلغ را وارد نمایید که مبلغ کل فرم های بالا همان مبلغ خواهد شد. همچنین می توانید مبالغ متفاوتی برای فرم هایتان ثبت کنید که با وارد کردن مبلغ هر فرم در کنار بازی مربوطه و ثبت فرم کلیه ی فرم های تکی را یکجا ثبت نمایید</p>
						<p><text style="color: #ffd33b !important;">میکس :</text> در زیر بازی ها به جز مورد تکی ها بقیه ی موارد مربوط به ثبت فرم میکس می باشد. برای درک بیشتر در مورد ثبت فرم میکس به تصویر زیر توجه کنید : (در اینجا برای مثال 5 ضریب بازی های مختلف را انتخاب کرده ایم)</p>
						<p class="text-center"><a href="<?php echo smarty_function_assets_url(array(),$_smarty_tpl);?>
/images/help_documention/image_3.png" target="_blank"><img src="<?php echo smarty_function_assets_url(array(),$_smarty_tpl);?>
/images/help_documention/image_3.png" style="cursor: zoom-in !important; max-width: 80% !important; height: auto !important;" class="img-responsive img-thumbnail" /></a></p>
						<p>موارد مربوط به ثبت فرم میکس توضیح داده می شود :</p>
						<p>2 تایی ها : می توانید فرم میکسی با 2 بازی ثبت کنید. عدد کنار 2 تایی ها که در اینجا 6 می باشد بدین معنی است که می توانید 6 بازی به صورت 2 تایی به شکل میکس ثبت کنید. ( 2 بازی را با هم میکس کنید )</p>
						<p>3 تایی ها : می توانید فرم میکسی با 3 بازی ثبت کنید. عدد کنار 3 تایی ها که در اینجا 4 می باشد بدین معنی است که می توانید 4 بازی به صورت 3 تایی به شکل میکس ثبت کنید. ( 3 بازی را با هم میکس کنید )</p>
						<p>4 تایی ها : می توانید فرم میکسی با 4 بازی ثبت کنید. عدد کنار 3 تایی ها که در اینجا 1 می باشد بدین معنی است که می توانید 1 بازی به صورت فرم میکس 4 تایی ثبت کنید. ( 4 بازی را با هم میکس کنید )</p>
						<p>توجه داشته باشید امکان ثبت فرم میکس تا 8 تایی ها امکان پذیر است</p>
						<p><text style="color: #ffd33b !important;">توجه :</text> در شرط بندی میکس حداکثر ضریب کل در هنگام برد ۱۰۰ محاسبه میشود. به این معنی که اگر شما روی میکسی شرط بندی کنید که ضریب کل فرم مثلا ۱۲۰ باشد و برنده شوید جایزه شما با ضرایب ۱۰۰ محاسبه خواهد شد</p>
					</div>
                </div>
            </div>
        </div>
    </div>
</div><?php }
}
