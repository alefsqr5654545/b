<?php
/* Smarty version 3.1.31, created on 2018-07-12 14:29:20
  from "C:\xampp\htdocs\themes\default\TkStarBet2018\modules\users\help\104.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.31',
  'unifunc' => 'content_5b47267876db51_17920535',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '0e1c7f0115fd81199286b247c8d7c60e1aa66b08' => 
    array (
      0 => 'C:\\xampp\\htdocs\\themes\\default\\TkStarBet2018\\modules\\users\\help\\104.tpl',
      1 => 1530233496,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:modules/users/help/menus.tpl' => 1,
  ),
),false)) {
function content_5b47267876db51_17920535 (Smarty_Internal_Template $_smarty_tpl) {
?>
<div class="container">
	<div class="page-content light">
		<div class="ph15"></div>
		<div class="inline container">
			<?php $_smarty_tpl->_subTemplateRender("file:modules/users/help/menus.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

			<div class="left static-content">
				<div class="page-area container inline form-container">
					<div class="page-title">راهنمای رولت</div>
					<div class="p15 text-content-page" style="font-size: 17px !important; text-align: justify !important;">
						<p>بازى رولت يك بازى مفرح در عين حال معروف ترين بازى كازينو در سراسر جهان مى باشد با بازى كردن رولت سايت بی وین سون يك كازينوى واقعى را تجربه خواهيد كرد يكى از معروف ترين شرط هاى اين بازى انتخاب رنگ است كه ظرف مدت چند ثانيه و با داشتن شانس مى تواند پول شما را دو برابر كند</p>
						<p>بازى رولت داراى حفره هاى شماره دار از ٠ تا ٣٦ در چرخه رولت است. براى بازى كردن در قسمت انتخاب ژتون، مبلغ مورد نظر خود را انتخاب كنيد پس از انتخاب ژتون روى ميز مورد نظر بر روى خانه يا شرط مورد نظر قرار دهيد و پس از اتمام شرط دكمه بچرخ را بزنيد</p>
						<p>
							شرط ضريب برد :<br>
							<text style="color: #ffd33b !important;">يك شماره :</text> 1 به 35<br>
							<text style="color: #ffd33b !important;">دو شماره :</text> 1 به 17<br>
							<text style="color: #ffd33b !important;">شرط روی خط ها :</text> 17 به 1<br>
							<text style="color: #ffd33b !important;">سه شماره :</text> 11 به 1<br>
							<text style="color: #ffd33b !important;">چهار شماره :</text> 8 به 1<br>
							<text style="color: #ffd33b !important;">شش شماره :</text> 5 به 1<br>
							<text style="color: #ffd33b !important;">ردیف :</text> 2 به 1<br>
							<text style="color: #ffd33b !important;">12 تایی :</text> 2 به 1<br>
							<text style="color: #ffd33b !important;">پایین (1 تا 18) :</text> 1 به 1<br>
							<text style="color: #ffd33b !important;">بالا (19 تا 36) :</text> 1 به 1<br>
							<text style="color: #ffd33b !important;">زوج :</text> 1 به 1<br>
							<text style="color: #ffd33b !important;">فرد :</text> 1 به 1<br>
							<text style="color: #ffd33b !important;">قرمز :</text> 1 به 1<br>
							<text style="color: #ffd33b !important;">سیاه :</text> 1 به 1
						</p>
					</div>
                </div>
            </div>
        </div>
    </div>
</div><?php }
}
