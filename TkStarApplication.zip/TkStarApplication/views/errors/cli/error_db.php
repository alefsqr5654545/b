<?php
echo "\nDatabase error: ",
	$heading,
	"\n\n",
	$message,
	"\n\n";