<?php
/* Smarty version 3.1.31, created on 2018-11-16 12:22:12
  from "/home/richbet/domains/richbet.xyz/public_html/themes/default/TkStarBet2018/modules/users/help/default.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.31',
  'unifunc' => 'content_5bee853cc7df68_91148869',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'f5c04f39a74488e1c398027a8d3f3f4b9e0f843e' => 
    array (
      0 => '/home/richbet/domains/richbet.xyz/public_html/themes/default/TkStarBet2018/modules/users/help/default.tpl',
      1 => 1530237852,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:modules/users/help/menus.tpl' => 1,
  ),
),false)) {
function content_5bee853cc7df68_91148869 (Smarty_Internal_Template $_smarty_tpl) {
if (!is_callable('smarty_function_site_url')) require_once '/home/richbet/domains/richbet.xyz/public_html/TkStarApplication/smarty/plugins/function.site_url.php';
?>
<style type="text/css">
	.hover-links {
		transition: all .35s ease-in !important;
	}
	.hover-links:hover {
		border: 1px solid #222222 !important;
		background-color: #ffd33b !important;
		color: black !important;
	}
</style>
<div class="container">
	<div class="page-content light">
		<div class="ph15"></div>
		<div class="inline container">
			<?php $_smarty_tpl->_subTemplateRender("file:modules/users/help/menus.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

			<div class="left static-content">
				<div class="page-area container inline form-container">
					<div class="page-title">راهنمای سایت</div>
					<div class="p15 text-content-page" style="font-size: 17px !important; text-align: justify !important;">
						<div class="row">لطفا راهنمای مورد نظر خود را انتخاب کنید . دقت داشته باشید برای استفاده از امکانات سایت می بایست تمامی بخش ها را مطالعه کنید . در صورت وجود مشکل لطفا از بخش حساب کاربری تیکت ارسال کنید</div>
						<div class="row">
							<div onclick="window.location = '<?php echo smarty_function_site_url(array(),$_smarty_tpl);?>
users/help/100';" class="col-lg-4" style="padding: 5px !important; text-align: center !important;"><div class="hover-links" style="cursor: pointer !important; height: 60px !important; padding: 15px !important; border: 1px solid white;">شرایط و ضوابط عضویت</div></div>
							<div onclick="window.location = '<?php echo smarty_function_site_url(array(),$_smarty_tpl);?>
users/help/101';" class="col-lg-4" style="padding: 5px !important; text-align: center !important;"><div class="hover-links" style="cursor: pointer !important; height: 60px !important; padding: 15px !important; border: 1px solid white;">راهنمای پیش بینی</div></div>
							<div onclick="window.location = '<?php echo smarty_function_site_url(array(),$_smarty_tpl);?>
users/help/102';" class="col-lg-4" style="padding: 5px !important; text-align: center !important;"><div class="hover-links" style="cursor: pointer !important; height: 60px !important; padding: 15px !important; border: 1px solid white;">آموزش ثبت فرم میکس</div></div>
							<div onclick="window.location = '<?php echo smarty_function_site_url(array(),$_smarty_tpl);?>
users/help/103';" class="col-lg-4" style="padding: 5px !important; text-align: center !important;"><div class="hover-links" style="cursor: pointer !important; height: 60px !important; padding: 15px !important; border: 1px solid white;">راهنمای تخته نرد</div></div>
							<div onclick="window.location = '<?php echo smarty_function_site_url(array(),$_smarty_tpl);?>
users/help/104';" class="col-lg-4" style="padding: 5px !important; text-align: center !important;"><div class="hover-links" style="cursor: pointer !important; height: 60px !important; padding: 15px !important; border: 1px solid white;">راهنمای رولت</div></div>
							<div onclick="window.location = '<?php echo smarty_function_site_url(array(),$_smarty_tpl);?>
users/help/105';" class="col-lg-4" style="padding: 5px !important; text-align: center !important;"><div class="hover-links" style="cursor: pointer !important; height: 60px !important; padding: 15px !important; border: 1px solid white;">راهنمای بلک جک (21)</div></div>
							<div onclick="window.location = '<?php echo smarty_function_site_url(array(),$_smarty_tpl);?>
users/help/106';" class="col-lg-4" style="padding: 5px !important; text-align: center !important;"><div class="hover-links" style="cursor: pointer !important; height: 60px !important; padding: 15px !important; border: 1px solid white;">راهنمای باکارات</div></div>
							<div onclick="window.location = '<?php echo smarty_function_site_url(array(),$_smarty_tpl);?>
users/help/107';" class="col-lg-4" style="padding: 5px !important; text-align: center !important;"><div class="hover-links" style="cursor: pointer !important; height: 60px !important; padding: 15px !important; border: 1px solid white;">راهنمای پاسور یا 4 برگ</div></div>
							<div onclick="window.location = '<?php echo smarty_function_site_url(array(),$_smarty_tpl);?>
users/help/108';" class="col-lg-4" style="padding: 5px !important; text-align: center !important;"><div class="hover-links" style="cursor: pointer !important; height: 60px !important; padding: 15px !important; border: 1px solid white;">روش های برداشت موجودی</div></div>
							<div onclick="window.location = '<?php echo smarty_function_site_url(array(),$_smarty_tpl);?>
users/help/109';" class="col-lg-4" style="padding: 5px !important; text-align: center !important;"><div class="hover-links" style="cursor: pointer !important; height: 60px !important; padding: 15px !important; border: 1px solid white;">نحوه کار با پرفکت مانی</div></div>
							<div onclick="window.location = '<?php echo smarty_function_site_url(array(),$_smarty_tpl);?>
users/help/110';" class="col-lg-4" style="padding: 5px !important; text-align: center !important;"><div class="hover-links" style="cursor: pointer !important; height: 60px !important; padding: 15px !important; border: 1px solid white;">احراز هویت</div></div>
							<div onclick="window.location = '<?php echo smarty_function_site_url(array(),$_smarty_tpl);?>
users/help/111';" class="col-lg-4" style="padding: 5px !important; text-align: center !important;"><div class="hover-links" style="cursor: pointer !important; height: 60px !important; padding: 15px !important; border: 1px solid white;">قمار ایمن</div></div>
							<div onclick="window.location = '<?php echo smarty_function_site_url(array(),$_smarty_tpl);?>
users/help/112';" class="col-lg-12" style="padding: 5px !important; text-align: center !important;"><div class="hover-links" style="cursor: pointer !important; height: 60px !important; padding: 15px !important; border: 1px solid white;">دزدی ها و کلاهبرداری های اینترنتی</div></div>
						</div>
					</div>
                </div>
            </div>
        </div>
    </div>
</div><?php }
}
