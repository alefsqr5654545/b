<?php
$config['unauthenticated_redirect'] = '/users/login';
$config['ssl_pages'] = array();
$config['parse_views'] = false;
$config['hash_secret'] = 'my_dirty_little_secret';
?>