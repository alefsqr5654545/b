<?php
class Exceptions extends CI_Form_validation {
    function __construct() {
        parent::__construct();
    }
}
?>