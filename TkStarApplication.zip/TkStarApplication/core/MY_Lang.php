<?php
require_once(APPPATH . 'libraries' . DS . 'Core' . DS . 'Lang.php');
class MY_Lang extends MX_Lang {}
?>