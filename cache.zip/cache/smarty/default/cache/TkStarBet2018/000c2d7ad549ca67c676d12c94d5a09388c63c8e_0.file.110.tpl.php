<?php
/* Smarty version 3.1.31, created on 2018-07-12 14:27:56
  from "C:\xampp\htdocs\themes\default\TkStarBet2018\modules\users\help\110.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.31',
  'unifunc' => 'content_5b472624e6abb7_07595816',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '000c2d7ad549ca67c676d12c94d5a09388c63c8e' => 
    array (
      0 => 'C:\\xampp\\htdocs\\themes\\default\\TkStarBet2018\\modules\\users\\help\\110.tpl',
      1 => 1530237180,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:modules/users/help/menus.tpl' => 1,
  ),
),false)) {
function content_5b472624e6abb7_07595816 (Smarty_Internal_Template $_smarty_tpl) {
?>
<div class="container">
	<div class="page-content light">
		<div class="ph15"></div>
		<div class="inline container">
			<?php $_smarty_tpl->_subTemplateRender("file:modules/users/help/menus.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

			<div class="left static-content">
				<div class="page-area container inline form-container">
					<div class="page-title">احراز هویت</div>
					<div class="p15 text-content-page" style="font-size: 17px !important; text-align: justify !important;">
						<p>احراز هويت براى تاييد واريزى شما مى باشد هنگامى كه زمان ورود به اكانت خود با پيغام "حساب كاربرى شما در حال بررسى مى باشد" رو به رو شديد، اكانت شما نياز به احراز هويت خواهد داشت لذا شما بايد بر روى گزينه "ارسال دوباره" كليك كرده و فرم مدارك را با دقت پر كنيد اگر هنگام پركردن فرم به مشكل خورديد مى توانيد تيكت ارسال كرده و مشكل خود را با پشتيبانى سايت در ميان بگذاريد</p>
						<p>توجه كنيد كه تمامى مداركى كه ارسال مى كنيد در سايت محفوظ بوده و به هيچ وجه امكان دسترسى ديگران به آن وجود ندارد و صرفا براى تاييد واريزى شما و جلوگيرى از دزدى ها و كلاهبردارى هاى اينترنتى مى باشد</p>
						<p>لطفا كارت بانكى كه با آن به سايت واريز انجام داديد را براى ما ارسال كنيد و براى برداشت نيز بايد از آن كارت استفاده نماييد</p>
					</div>
                </div>
            </div>
        </div>
    </div>
</div><?php }
}
