<?php
/* Smarty version 3.1.31, created on 2018-12-21 05:10:06
  from "/home/richbet/public_html/themes/default/TkStarBet2018/modules/users/help/111.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.31',
  'unifunc' => 'content_5c1c4476c7a908_35434095',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'af5b72e0731ae35eecb5dccd1f335b29c04c5e14' => 
    array (
      0 => '/home/richbet/public_html/themes/default/TkStarBet2018/modules/users/help/111.tpl',
      1 => 1530237322,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:modules/users/help/menus.tpl' => 1,
  ),
),false)) {
function content_5c1c4476c7a908_35434095 (Smarty_Internal_Template $_smarty_tpl) {
?>
<div class="container">
	<div class="page-content light">
		<div class="ph15"></div>
		<div class="inline container">
			<?php $_smarty_tpl->_subTemplateRender("file:modules/users/help/menus.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

			<div class="left static-content">
				<div class="page-area container inline form-container">
					<div class="page-title">قمار ایمن</div>
					<div class="p15 text-content-page" style="font-size: 17px !important; text-align: justify !important;">
						<p style="color: #ffd33b !important;">توجه : قمار را به عنوان راهى براى فرار از مشكلات مالى انجام ندهيد</p>
						<p>- براى اشخاصى كه تمايل به قمار كردن دارند اصولى وجود دارد كه ريسك مشكلات ناشى از قمار را كاهش داده و به آن ها كمك مى كند ايمن تر قمار كنند. قمار را به عنوان روشى براى پول در آوردن در نظر نگيريد</p>
						<p>- هميشه با در نظر گرفتن مبلغى كه در صورت باخت توانايى پرداخت آن را داريد قمار كنيد به عنوان مثال با مبلغى كه براى تفريح روزانه خود در نظر گرفتيد قمار كنيد مانند رفتن به سينما. هرگز از مبلغى كه براى امور مهم خود مانند اجاره بها، صورتحساب و قبوض، شهريه و غيره در نظر گرفته ايد استفاده نكنيد</p>
						<p>- محدوديت مالى و زمانى براى بازى خود قرار دهيد</p>
						<p>- قبل از شروع بازى مقدار پول كه توانايى پرداخت آن را در صورت باخت داريد مشخص كنيد اگر همان مقدار پول را باختيد از بازى كنار رفته و در صورت برد از بازى لذت ببريد</p>
						<p>- هرگز در جبران باخت هاى خود اصرار نورزيد سعى نكنيد با بازى مجدد آن مبلغ را مجددا برنده شويد چون ممكن است موجب باخت هاى سنگين تر شود</p>
						<p>- در زمان هايى كه ناراحت و افسرده هستيد قمار نكنيد هنگام ناراحتى تصميم گيرى دشوار است سعى كنيد توازن بين قمار و فعاليت هاى ديگر زندگى برقرار كنيد</p>
					</div>
                </div>
            </div>
        </div>
    </div>
</div><?php }
}
