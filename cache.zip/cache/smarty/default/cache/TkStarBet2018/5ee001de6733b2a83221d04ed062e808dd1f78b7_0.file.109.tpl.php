<?php
/* Smarty version 3.1.31, created on 2018-07-12 14:28:04
  from "C:\xampp\htdocs\themes\default\TkStarBet2018\modules\users\help\109.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.31',
  'unifunc' => 'content_5b47262c872161_36245235',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '5ee001de6733b2a83221d04ed062e808dd1f78b7' => 
    array (
      0 => 'C:\\xampp\\htdocs\\themes\\default\\TkStarBet2018\\modules\\users\\help\\109.tpl',
      1 => 1530237108,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:modules/users/help/menus.tpl' => 1,
  ),
),false)) {
function content_5b47262c872161_36245235 (Smarty_Internal_Template $_smarty_tpl) {
?>
<div class="container">
	<div class="page-content light">
		<div class="ph15"></div>
		<div class="inline container">
			<?php $_smarty_tpl->_subTemplateRender("file:modules/users/help/menus.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

			<div class="left static-content">
				<div class="page-area container inline form-container">
					<div class="page-title">نحوه کار با پرفکت مانی</div>
					<div class="p15 text-content-page" style="font-size: 17px !important; text-align: justify !important;">
						<p>لازم به ذکر است این توضیحات ممکن است در ابتدا دشوار، طولانی و خسته کننده باشد ولی فقط چند دقیقه از وقت شما را خواهد گرفت با مطالعه دقیق این مطالب به راحتی قادر به شارژ حساب خود خواهید شد</p>
						<p style="color: #ffd33b !important;">نحوه افزایش موجودی :</p>
						<p>
							<text style="color: #ffd33b !important;">1- خرید کارت شارژ پرفکت مانی (ووچر پرفکت مانی)</text><br>
							این روش یکی از مطمئن ترین و امن ترین روش های شارژ برای سایت های پیش بینی و بازی های آنلاین می باشد در این روش، شما نیاز به داشتن حساب پرفکت مانی ندارید، لذا کاربران تنها با خرید ووچر از هزاران سایت ایرانی امکان افزایش موجودی در حساب کاربری خود را دارند در اینجا لیستی از سایت های معتبر در این زمینه را معرفی کردیم :<br><br>
							<a href="http://www.pm4ir.com/" target="_blank">www.pm4ir.com</a><br>
							<a href="http://www.wmfa.ir/" target="_blank">www.wmfa.ir</a><br>
							<a href="http://www.farhadexchange.net/" target="_blank">www.farhadexchange.net</a><br>
							<a href="http://www.payment24.ir/" target="_blank">www.payment24.ir</a><br>
							<a href="http://www.change4.ir/" target="_blank">www.change4.ir</a><br><br>
							کارت شارژ پرفکت مانی یا ووچر از یک شماره رمز و کد فعال سازی تشکیل شده است که با داشتن این رمز می توانید وارد بخش افزایش موجودی شوید و گزینه شارژ از طریق ووچر را انتخاب کرده و با وارد کردن این ۲ کد حساب خود را بلافاصله شارژ نمایید<br>
							برای خرید ووچر از هر صرافی می توانید استفاده کنید، و احراز هویت برای خرید در این صرافی ها الزامی می باشد. مراحل خرید در این سایت ها بصورت کاملا اتوماتیک بوده و پس از پرداخت بلافاصله کارت ووچر خود را دریافت می کنید<br><br>
							<text style="color: #ffd33b !important;">2- شارژ از طریق درگاه پرفکت مانی</text><br>
							پرفكت مانى نوعى دلار الكترونيكى مى باشد كه شما مى توانيد از طريق صرافى هاى معتبر اقدام به خريد دلار كرده و حساب خود را شارژ نماييد. لازم به ذكر است كه مراحل پرفكت مانى در ابتدا دشوار به نظر مى رسد ولى پس از ثبت نام به راحتى حساب خود را شارژ خواهيد كرد و اين روش داراى امنيت بالايى براى كاربران ايرانى مى باشد<br>
							<text style="color: #ffd33b !important;">مراحل ثبت نام و شارژ به صورت زير مى باشد :</text><br>
							-  ابتدا در سايت پرفكت مانى ثبت نام كنيد، مى توانيد براى راحتى زبان سايت را به فارسى تغيير دهيد، سپس ايميلى براى شما ارسال خواهد شد كه حاوى لينك فعالسازى و شماره حساب كاربرى شما هست، هر حساب پرفكت مانى داراى عددى مى باشد كه با (U14810***) شروع مى شود اين عدد كيف پول شما نام دارد و به منزله شماره حساب دلارى شما مى باشد<br>
							-  به يك سايت صرافى معتبر مراجعه كرده و قسمت خريد دلار پرفكت مانى را انتخاب كنيد سپس كيف پول خود را كه از اكانت خود در اختيار داريد وارد كنيد و صبر كنيد تا حساب شما شارژ شود<br><br>
							<text style="color: #ffd33b !important;">چند نكته :</text><br>
							در انتخاب صرافى خود دقت كنيد پيشنهاد ما به شما سايت هاى فرهاد اكسچنج و چنج برای ایران مى باشد<br>
							برخى از سايت هاى صرافى داراى احراز هويت مى باشد كه اين امر براى امنيت خردي دلار شما مى باشد و هيچ مشكلى ندارد<br>
							پس از خريد ممكن است حساب شما بلافاصله شارژ نشود كه بسته به نحوه و ساعات كارى آن صرافى مى توانيد از طريق پشتيبانى آن صرافى پيگيرى نماييد. صرافی های نام برده تمام خودکار می باشند. هنگام وارد كردن كيف پول مقصد دقت نماييد<br><br>
							- پس از شارژ، ايميلى حاوى محتويات پرداخت شما ارسال مى شود كه شارژ حساب پرفكت مانى شما را تاييد مى كند<br>
							- وارد سايت ما شده و قسمت شارژ حساب، شارژ از طريق پرفكت مانى را انتخاب كنيد<br>
							-  سپس بر روى گزينه perfect money account كليك كنيد<br>
							<text style="color: #ffd33b !important;">Member ID :</text> همان شماره كاربرى شما در سايت مى باشد كه به ايميل شما ارسال مى شود<br>
							<text style="color: #ffd33b !important;">Password :</text> رمز ثبت نامى حساب شما مى باشد در صورت وارد كردن صحيح اطلاعات و بودن موجودى كافى حساب كاربرى به صورت آنى شارژ خواهد شد
					</div>
                </div>
            </div>
        </div>
    </div>
</div><?php }
}
