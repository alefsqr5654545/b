<?php
require_once __DIR__ . '/composer' . '/autoload_real.php';
return ComposerAutoloaderInit389393c90e26282960c95ba4200274b1::getLoader();
?>