<?php
namespace Baum;

class MoveNotPossibleException extends \RuntimeException {}
