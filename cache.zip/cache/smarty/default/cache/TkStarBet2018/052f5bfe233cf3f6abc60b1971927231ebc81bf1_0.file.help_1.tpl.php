<?php
/* Smarty version 3.1.31, created on 2018-06-26 08:17:32
  from "C:\xampp\htdocs\themes\default\TkStarBet2018\modules\users\help_1.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.31',
  'unifunc' => 'content_5b31b754945233_06954743',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '052f5bfe233cf3f6abc60b1971927231ebc81bf1' => 
    array (
      0 => 'C:\\xampp\\htdocs\\themes\\default\\TkStarBet2018\\modules\\users\\help_1.tpl',
      1 => 1529984740,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5b31b754945233_06954743 (Smarty_Internal_Template $_smarty_tpl) {
?>
asdasdsadsadsa<?php }
}
