<?php
$lang['no content type exists']='شما هنوز هیچ نوع محتوایی ایجاد نکرده اید، برای شروع روی این لینک کلیک کنید.';
$lang['no content type exists title']='هیچ نوعی برای داده ها یافت نشد.';
?>