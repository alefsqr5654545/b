<?php
/* Smarty version 3.1.31, created on 2018-06-26 04:49:48
  from "C:\xampp\htdocs\themes\default\TkStarBet2018\modules\content\pages\statics\404.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.31',
  'unifunc' => 'content_5b3186a4e87f53_67618452',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '0beb3bfeb2046ae08721b4263862b641fac1b881' => 
    array (
      0 => 'C:\\xampp\\htdocs\\themes\\default\\TkStarBet2018\\modules\\content\\pages\\statics\\404.tpl',
      1 => 1485118996,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5b3186a4e87f53_67618452 (Smarty_Internal_Template $_smarty_tpl) {
?>

<!-- error-page start -->
<div class="error-page">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="four-zero-four">
                    <h1><span><?php echo $_smarty_tpl->tpl_vars['page']->value['title'];?>
</span></h1>
                    <label><?php echo $_smarty_tpl->tpl_vars['page']->value['description'];?>
</label>
                </div>					
            </div>
        </div>
    </div>
</div>
<!-- error-page end -->
<?php }
}
