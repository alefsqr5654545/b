<?php
function smarty_function_site_url($params, Smarty_Internal_Template $template)
{
    return base_url();
}
?>