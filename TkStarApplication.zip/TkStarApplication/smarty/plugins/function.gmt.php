<?php

/*
 * Smarty plugin
 * -------------------------------------------------------------
 * File:     function.jdate.php
 * Type:     function
 * Name:     jdate
 * Purpose:  georgian date to jalali 
 * -------------------------------------------------------------
 */

function smarty_function_gmt ( $params , Smarty_Internal_Template $template ) {
}
