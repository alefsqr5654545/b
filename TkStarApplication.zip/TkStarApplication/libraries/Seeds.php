<?php
class Seeds {
    public function seed_do($module_name, $seed_name) {
    }
}
?>