<?php
/* Smarty version 3.1.31, created on 2019-03-17 01:44:31
  from "C:\xampp\htdocs\00\themes\default\TkStarBet2018\modules\users\casino.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.31',
  'unifunc' => 'content_5c8d75475acc45_31088757',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '52de3811c8e2767920460d6906cdd070d9de9a84' => 
    array (
      0 => 'C:\\xampp\\htdocs\\00\\themes\\default\\TkStarBet2018\\modules\\users\\casino.tpl',
      1 => 1544618169,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5c8d75475acc45_31088757 (Smarty_Internal_Template $_smarty_tpl) {
if (!is_callable('smarty_function_site_url')) require_once 'C:\\xampp\\htdocs\\00\\TkStarApplication\\smarty\\plugins\\function.site_url.php';
?>
	<div class="page-content light">
		<div class="mr10 mt5">
			<div class="page-area container inline form-container dark">
				<div class="page-title">کازینو آنلاین</div>
				<div class="p15">
					<div class="row">
						<div class="col-lg-4" style="margin-bottom: 25px !important;">
							<a href="<?php echo smarty_function_site_url(array(),$_smarty_tpl);?>
casino/crash" title="Iranian Crash" class="item-box">
								<div class="image"><img src="http://<?php echo getenv('SERVER_NAME');?>
/casino/templates/images/logoes/crash.png" style="width: 100% !important; height: 100% !important;" class="img-responsive" /></div>
								<div class="title"><div>بازی انفجار</div></div>
							</a>
						</div>
						<div class="col-lg-4" style="margin-bottom: 25px !important;">
							<a href="<?php echo smarty_function_site_url(array(),$_smarty_tpl);?>
casino/baccarat" title="Iranian Baccarat" class="item-box">
								<div class="image"><img src="http://<?php echo getenv('SERVER_NAME');?>
/casino/templates/images/logoes/baccarat.png" style="width: 100% !important; height: 100% !important;" class="img-responsive" /></div>
								<div class="title"><div>باکارات</div></div>
							</a>
						</div>
						<div class="col-lg-4" style="margin-bottom: 25px !important;">
							<a href="<?php echo smarty_function_site_url(array(),$_smarty_tpl);?>
casino/blackjack" title="Iranian BlackJack (21)" class="item-box">
								<div class="image"><img src="http://<?php echo getenv('SERVER_NAME');?>
/casino/templates/images/logoes/blackjack.png" style="width: 100% !important; height: 100% !important;" class="img-responsive" /></div>
								<div class="title"><div>بلک جک (21)</div></div>
							</a>
						</div>
						<div class="col-lg-4" style="margin-bottom: 25px !important;">
							<a href="<?php echo smarty_function_site_url(array(),$_smarty_tpl);?>
casino/royal_roulette" title="Iranian Royal Roulette" class="item-box">
								<div class="image"><img src="http://<?php echo getenv('SERVER_NAME');?>
/casino/templates/images/logoes/royal_roulette.png" style="width: 100% !important; height: 100% !important;" class="img-responsive" /></div>
								<div class="title"><div>رویال رولت</div></div>
							</a>
						</div>
						<div class="col-lg-4" style="margin-bottom: 25px !important;">
							<a href="<?php echo smarty_function_site_url(array(),$_smarty_tpl);?>
casino/seven_clubs" title="Iranian Seven Clubs" class="item-box">
								<div class="image"><img src="http://<?php echo getenv('SERVER_NAME');?>
/casino/templates/images/logoes/seven_clubs.png" style="width: 100% !important; height: 100% !important;" class="img-responsive" /></div>
								<div class="title"><div>چهار برگ (هفت خاج)</div></div>
							</a>
						</div>
						<div class="col-lg-4" style="margin-bottom: 25px !important;">
							<a href="<?php echo smarty_function_site_url(array(),$_smarty_tpl);?>
casino/two_verdicts" title="Iranian Two Verdicts" class="item-box">
								<div class="image"><img src="http://<?php echo getenv('SERVER_NAME');?>
/casino/templates/images/logoes/two_verdicts.png" style="width: 100% !important; height: 100% !important;" class="img-responsive" /></div>
								<div class="title"><div>حکم دو نفره</div></div>
							</a>
						</div>
						<div class="col-lg-4" style="margin-bottom: 25px !important;">
							<a href="<?php echo smarty_function_site_url(array(),$_smarty_tpl);?>
casino/plinko" title="Iranian Plinko" class="item-box">
								<div class="image"><img src="http://<?php echo getenv('SERVER_NAME');?>
/casino/templates/images/logoes/plinko.png" style="width: 100% !important; height: 100% !important;" class="img-responsive" /></div>
								<div class="title"><div>توپ و سبد</div></div>
							</a>
						</div>
						<div class="col-lg-4" style="margin-bottom: 25px !important;">
							<a href="<?php echo smarty_function_site_url(array(),$_smarty_tpl);?>
casino/craps" title="Iranian Craps" class="item-box">
								<div class="image"><img src="http://<?php echo getenv('SERVER_NAME');?>
/casino/templates/images/logoes/craps.png" style="width: 100% !important; height: 100% !important;" class="img-responsive" /></div>
								<div class="title"><div>زمین و تاس (کرپس)</div></div>
							</a>
						</div>
						<div class="col-lg-4" style="margin-bottom: 25px !important;">
							<a href="<?php echo smarty_function_site_url(array(),$_smarty_tpl);?>
casino/fortune_wheel" title="Iranian Fortune Wheel" class="item-box">
								<div class="image"><img src="http://<?php echo getenv('SERVER_NAME');?>
/casino/templates/images/logoes/fortune_wheel.png" style="width: 100% !important; height: 100% !important;" class="img-responsive" /></div>
								<div class="title"><div>گردونه شانس</div></div>
							</a>
						</div>
						<div class="col-lg-4" style="margin-bottom: 25px !important;">
							<a href="<?php echo smarty_function_site_url(array(),$_smarty_tpl);?>
casino/high_low" title="Iranian High Low" class="item-box">
								<div class="image"><img src="http://<?php echo getenv('SERVER_NAME');?>
/casino/templates/images/logoes/high_low.png" style="width: 100% !important; height: 100% !important;" class="img-responsive" /></div>
								<div class="title"><div>کمتر بیشتر</div></div>
							</a>
						</div>
					</div>
					<div class="clear"></div>
				</div>
			</div>
		</div>
		<div class="ph15"></div>
	</div><?php }
}
