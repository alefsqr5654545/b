<?php
$database = array();
$database['hostname'] = 'localhost';
$database['username'] = 'cupabet_ghIo26';
$database['password'] = '+Z}%46#f#~1D';
$database['database'] = 'cupabet_ghIo26';
$database['dbdriver'] = 'mysqli';
$database['dbprefix'] = '';
$database['port'] = 3306;
$database['pconnect'] = false;
$database['db_debug'] = false;
$database['cache_on'] = false;
$database['cachedir'] = '';
$database['char_set'] = 'utf8';
$database['dbcollat'] = 'utf8_general_ci';
$database['swap_pre'] = '';
$database['autoinit'] = false;
$database['stricton'] = false;
?>