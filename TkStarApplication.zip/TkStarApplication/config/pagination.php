<?php
$config['uri_segment'] = 3;
$config['per_page'] = 50;
$config['num_links'] = 3;
$config['first_link'] = false;
$config['first_tag_open'] = ' ';
$config['first_tag_close'] = '';
$config['last_link'] = false;
$config['last_tag_open'] = '';
$config['last_tag_close'] = '';
$config['num_tag_open'] = '';
$config['num_tag_close'] = '';
$config['cur_tag_open'] = '<a href="#" class="active2">';
$config['cur_tag_close'] = '</a>';
$config['next_tag_open'] = '<a>';
$config['next_tag_close'] = '</a>';
$config['next_link'] = ' <i class="fa fa-chevron-right"></i> ';
$config['prev_link'] = ' <i class="fa fa-chevron-left"></i> ';
$config['prev_tag_open'] = '';
$config['prev_tag_close'] = '';
$config['use_page_numbers'] = true;
?>