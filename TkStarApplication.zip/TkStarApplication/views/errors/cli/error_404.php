<?php
echo "\nERROR: ",
	$heading,
	"\n\n",
	$message,
	"\n\n";