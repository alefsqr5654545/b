<?php
$lang['gigabyte_abbr'] = 'گیگابایت';
$lang['megabyte_abbr'] = 'مگابایت';
$lang['kilobyte_abbr'] = 'کیلوبایت';
$lang['bytes'] = 'بایت';
?>