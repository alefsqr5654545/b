<?php
/* Smarty version 3.1.31, created on 2018-11-14 15:33:49
  from "/home/richbet/domains/richbet.xyz/public_html/themes/default/TkStarBet2018/modules/users/help/106.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.31',
  'unifunc' => 'content_5bec0f25608a42_39606817',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '5b4ce2ccb660d581092ae560ec9fc28ad71785b8' => 
    array (
      0 => '/home/richbet/domains/richbet.xyz/public_html/themes/default/TkStarBet2018/modules/users/help/106.tpl',
      1 => 1530233876,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:modules/users/help/menus.tpl' => 1,
  ),
),false)) {
function content_5bec0f25608a42_39606817 (Smarty_Internal_Template $_smarty_tpl) {
?>
<div class="container">
	<div class="page-content light">
		<div class="ph15"></div>
		<div class="inline container">
			<?php $_smarty_tpl->_subTemplateRender("file:modules/users/help/menus.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

			<div class="left static-content">
				<div class="page-area container inline form-container">
					<div class="page-title">راهنمای باکارات</div>
					<div class="p15 text-content-page" style="font-size: 17px !important; text-align: justify !important;">
						<p>اين بازى آسان ترين بازى كازينو است اما به دليل سادگى محبوبيت و جذابيتى بين مردم دارد اين بازى بين دو طرف بازيكن و بانکر انجام مى شود</p>
						<p>هدف از بازى باكارات به طور ساده اين است كه پيش بينى كنيد دست كداميك (بانكر يا بازيكن) به عدد ٩ نزديك تر است يا مساوى (TIE) مى باشد ديلر به هر كدام دو كارت مى دهد (ممكن است كارت سوم نيز داده شود) كه ارزش كارت ها مشخص شده و برنده اعلام مى شود</p>
						<p>
							<text style="color: #ffd33b !important;">امتیاز کارت ها :</text><br>
							(شاه) و  Q (بی بی) و J (سرباز) و ١٠ همه اين كارت ها صفر امتياز دارند<br>
							آس ١ امتياز دارد<br>
							اعداد ٢ تا ٩ امتياز خودشان يعنى عدد درج شده روى كارت را دارند<br>
							ارزش دست با جمع امتياز ها مشخص مى شود اگر جمع شمارش بيشتر از ١٠ شد ١٠ تا از آن كم مى شود تا ارزش دست ها مشخص شود<br>
						</p>
					</div>
                </div>
            </div>
        </div>
    </div>
</div><?php }
}
