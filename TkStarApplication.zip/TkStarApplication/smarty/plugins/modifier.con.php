<?php
function smarty_modifier_con() {
    return implode(func_get_args());
}
?>