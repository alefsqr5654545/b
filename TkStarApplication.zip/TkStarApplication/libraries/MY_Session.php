<?php
class MY_Session {
}
?>